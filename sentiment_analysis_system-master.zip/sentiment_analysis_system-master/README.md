# sentiment_analysis_system
it is a simple Natural Language Processing project in python.
